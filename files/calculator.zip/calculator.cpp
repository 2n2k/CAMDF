#include <iostream>
#include <string>
#include <sstream>

// The flag is: FLAM{C0RR3CT_C4LCUL4T0R_FL4G}

bool jD3eF(const std::string& OvR) {
    return OvR == "+" || OvR == "-" || OvR == "*" || OvR == "/";
}

std::string SpvRe() {
    std::string hiddenpassword = "password";
    std::string p = "wr0ng";
    std::string pp = "l00k_3lsewh3re";
    std::string ppp = "3z_pz_l3mon_squ33zy";
    std::string pppp = "r00llling";
    std::string ppppp = "f00l3d";
    std::string pppppp = "AYO0O0O0O";
    std::string ppppppp = "M4t4s";
    std::string pppppppp = "4dr1s";
    std::string ppppppppp = "wh4ttt";
    std::string pppppppppp = "FLAM{C4LCUL4TOR_FL4G}";
    std::string password = "admin123";
    std::string realpassword = "s33cretss_";
    return ppppp;
}

bool nYiU(const std::string& ZBk) {
    std::istringstream VoT(ZBk);
    double h1pT;
    return VoT >> h1pT && VoT.eof();
}

std::string HcWqX() {
    std::string s2mP;
    int vLXj[] = { 75, 81, 70, 82, 128, 73, 56, 91, 100, 72, 57, 81, 72, 90, 81, 57, 89, 53, 87, 130 };

    int XaVd = 5;
    for (int i = 0; i < sizeof(vLXj) / sizeof(vLXj[0]); ++i) {
        s2mP += static_cast<char>(vLXj[i] - XaVd);
    }

    return s2mP;
}

int main() {
    std::string uqLpJ;
    double bIqA, sLgO, wKpC;
    std::cout << "What calculations would you like to perform? Current selections: + - * /" << '\n';
    std::cin >> uqLpJ;

    if (uqLpJ == "developer") {
        std::cout << "Enter password: " << '\n';
        std::string jKdQn;
        std::cin >> jKdQn;
        if (jKdQn == SpvRe() ){
            system("cls");
            std::cout << HcWqX() << '\n';
            system("pause");
            return 0;
        }
        else {
            std::cout << "Incorrect!" << '\n';
            system("pause");
            return 1;
        }
    }
    else if (jD3eF(uqLpJ)) {
        std::cout << "Input 1st and 2nd number:" << '\n';
        std::string F2lN, F2lO;
        std::cin >> F2lN >> F2lO;

        if (!nYiU(F2lN) || !nYiU(F2lO)) {
            std::cout << "Invalid number input!" << '\n';
            system("pause");
            return 1;
        }

        bIqA = std::stod(F2lN);
        sLgO = std::stod(F2lO);

        if (uqLpJ == "+") {
            wKpC = bIqA + sLgO;
        }
        else if (uqLpJ == "-") {
            wKpC = bIqA - sLgO;
        }
        else if (uqLpJ == "*") {
            wKpC = bIqA * sLgO;
        }
        else if (uqLpJ == "/") {
            if (sLgO != 0) {
                wKpC = bIqA / sLgO;
            }
            else {
                std::cout << "Error! Division by zero";
                system("pause");
                return 1;
            }
        }
        std::cout << "Result: " << wKpC << '\n';
    }
    else {
        std::cout << "Invalid operator" << '\n';
        system("pause");
        return 1;
    }
    system("pause");
    return 0;
}
